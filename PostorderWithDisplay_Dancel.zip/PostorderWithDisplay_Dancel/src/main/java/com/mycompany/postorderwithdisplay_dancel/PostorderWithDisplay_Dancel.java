/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.postorderwithdisplay_dancel;

/**
 *
 * @author USER
 */
import java.util.Scanner;

class Node {

    int data;
    Node left;
    Node right;

    Node(int x) {
        data = x;
        left = null;
        right = null;
    }
}

public class PostorderWithDisplay_Dancel {

    static class BinarySearchTree {

        public Node root; // root of the BST

        public String postorderTraversal() { // method postorder traversal
            return postorder(root, "");
        }

        String postorder(Node node, String result) { // method for postorder traversal
            if (node != null) { // if current node is not null
                result = postorder(node.left, result); // traverse left subtree
                result = postorder(node.right, result); // traverse right subtree
                result += node.data + " "; // process current node (add value to result)
            }
            return result;
        }

        public void insert(int value) { // method to insert a new node
            root = insertRecursive(root, value);
        }

        Node insertRecursive(Node current, int value) {
            if (current == null) {
                return new Node(value);
            }

            if (value < current.data) {
                current.left = insertRecursive(current.left, value);
            } else if (value > current.data) {
                current.right = insertRecursive(current.right, value);
            }

            return current;
        }

        public void delete(int value) { // method to delete a node
            root = deleteValue(root, value);
        }

        Node deleteValue(Node current, int value) {
            if (current == null) {
                return null;
           }

            if (value < current.data) {
                current.left = deleteValue(current.left, value);
            } else if (value > current.data) {
                current.right = deleteValue(current.right, value);
            } else {
                // Node found, delete it
                if (current.left == null && current.right == null) {
                    return null;
                } else if (current.left == null) {
                    return current.right;
                } else if (current.right == null) {
                    return current.left;
                } else {
                    // node has two children, find the minimum in the right subtree
                    Node minNode = findMinNode(current.right);
                    current.data = minNode.data;
                    current.right = deleteValue(current.right, minNode.data);
                }
            }

            return current;
        }

        Node findMinNode(Node node) {
            while (node.left != null) {
                node = node.left;
            }
            return node;
        }

        void printWhitespaces(int count) {
            for (int i = 0; i < count; i++) {
                System.out.print(" ");
            }
        }

        void displayNode(Node node, int level, int maxLevel) { //method to print the tree
            if (node == null) {
                return;
            }

            int floor = maxLevel - level;
            int edgeLines = (int) Math.pow(2, Math.max(floor - 1, 0));
            int firstSpaces = (int) Math.pow(2, floor) - 1;
            int betweenSpaces = (int) Math.pow(2, floor + 1) - 1;

            printWhitespaces(firstSpaces);
            System.out.print(node.data);
            printWhitespaces(betweenSpaces);
            System.out.println();

            for (int i = 1; i <= edgeLines; i++) {
                printWhitespaces(firstSpaces - i);
                if (node.left != null) {
                    System.out.print("/");
                } else {
                    printWhitespaces(1);
                }

                printWhitespaces(i + i - 1);

                if (node.right != null) {
                    System.out.print("\\");
                } else {
                    printWhitespaces(0);
                }

                printWhitespaces(edgeLines + edgeLines - i);
                System.out.println();
            }

            if (node.left != null) {
                displayNode(node.left, level + 1, maxLevel);
            }
            if (node.right != null) {
                displayNode(node.right, level + 1, maxLevel);
            }
        }

        int maxLevel(Node node) {
            if (node == null) {
                return 0;
            }
            return 1 + Math.max(maxLevel(node.left), maxLevel(node.right));
        }
    }

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        BinarySearchTree binarySearchTree = new BinarySearchTree();

        binarySearchTree.insert(5); // assuming you want to insert the root node here
        binarySearchTree.insert(10);
        binarySearchTree.insert(3);

        while (true) {
            System.out.println("1. Insert a node");
            System.out.println("2. Delete a node");
            System.out.println("3. Print Postorder Traversal");
            System.out.println("4. Print Binary Tree Structure");
            System.out.println("5. Exit");
            System.out.print("Enter your choice:");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter a value to insert:");
                    int insertValue = scanner.nextInt();
                    binarySearchTree.insert(insertValue);
                    break;
                case 2:
                    System.out.print("Enter a value to delete:");
                    int deleteValue = scanner.nextInt();
                    binarySearchTree.delete(deleteValue);
                    break;
                case 3:
                    System.out.println("Postorder Traversal: " + binarySearchTree.postorderTraversal());
                    break;
                case 4:
                    int maxLvl = binarySearchTree.maxLevel(binarySearchTree.root);
                    System.out.println("Binary Tree Structure:");
                    binarySearchTree.displayNode(binarySearchTree.root, 0, maxLvl);
                    break;
                case 5:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
