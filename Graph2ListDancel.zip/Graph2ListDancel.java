/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.graph2listdancel;

/**
 *
 * @author USER
 */

import java.util.*; //use to access arraylist(resizable array) and linkedlist
public class Graph2ListDancel {
    
    static class Node {
        int value; //
        
        Node (int value) {
           this.value=value; 
        }
    }
    
    static class Graph {
        ArrayList<LinkedList<Node>> adjacentList; 
        
        Graph(){
            adjacentList = new ArrayList<>(); 
	}
	
        //Method to Add Node
	public void addNode(Node node) {
		LinkedList<Node> currList = new LinkedList<>();
		currList.add(node);  
		adjacentList.add(currList); 
	}
        
        //Method to Add Edges
	public void addEdge(int src, int dst) { 
		LinkedList<Node> currList = adjacentList.get(src); 
                Node dstNode = adjacentList.get(dst).get(0); 
		currList.add(dstNode); 
                
                //For Undirected Graph
                LinkedList<Node> dstList = adjacentList.get(dst); 
                Node srcNode = adjacentList.get(src).get(0);
                dstList.add(srcNode);
        }
        
        //Method to Print Adjacent List
	public void printAdjacentList () {
            for (int i = 0; i < adjacentList.size(); i++) { 
		LinkedList<Node> currList=adjacentList.get(i);  
                    for (int j = 0; j < currList.size(); j++) { 
			System.out.print(currList.get(j).value); 
			if (j<currList.size()-1) { 
                            System.out.print("-->"); 
                        }
                    }
                    System.out.println();
            }	
        }
    }
    
    public static void main(String[] args) {
        Graph graphList = new Graph(); //instantiate Graph
		
        //Add Nodes
        for (int i=0; i<=9; i++) {
            graphList.addNode(new Node(i)); 
        }
                
        //Add Edges
	graphList.addEdge(0, 1);
        graphList.addEdge(0, 3); 
        graphList.addEdge(0, 5);
        graphList.addEdge(1, 3);
        graphList.addEdge(1, 8); 
        graphList.addEdge(2, 5); 
        graphList.addEdge(2, 7); 
        graphList.addEdge(2, 8);
        graphList.addEdge(3, 4); 
        graphList.addEdge(3, 6);
        graphList.addEdge(4, 6);
        graphList.addEdge(4, 9);
        graphList.addEdge(5, 6); 
        graphList.addEdge(8, 9); 
        
        //Print adjacent list
        graphList.printAdjacentList();
    }
}